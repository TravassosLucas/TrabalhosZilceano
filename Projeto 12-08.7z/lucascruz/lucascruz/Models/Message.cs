﻿namespace lucascruz.Models
{
    public class Message
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Content { get; set; }
    }
}

