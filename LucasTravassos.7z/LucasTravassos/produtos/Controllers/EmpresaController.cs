using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class EmpresaController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new  Empresa{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var empresas = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Nome = "Tesla",
                    Taxa = 22.45m,
                    Endereço = "USA",
                    Cnpj = "1232465576",
                    Fiscal = "MEI",
                    Data = DateTime.Now
                },
                new Empresa{
                     Id = 2,
                    Nome = "SpaceX",
                    Taxa = 222.45m,
                    Endereço = "USA",
                    Cnpj = "12324655676",
                    Fiscal = "MEI",
                    Data = DateTime.Now
                },
                new Empresa
                {
                    Id = 3,
                    Nome = "Blue Origin",
                    Taxa = 10.15m,
                    Endereço = "USA",
                    Cnpj = "12324655576",
                    Fiscal = "MEI",
                    Data = DateTime.Now
                }            
            };


            return View(empresas);
        }
    }
}
