using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Lucas",
                    Cpf = 1324726106,
                    Telefone = 54745289,
                    Pedido = "O melhor Laranja que você tem.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 2,
                    Nome = "Yuri",
                    Cpf = 1324726506,
                    Telefone = 54745289,
                    Pedido = "O melhor Laranja que você tem.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 2,
                    Nome = "Neil",
                    Cpf = 1324722606,
                    Telefone = 54745289,
                    Pedido = "O melhor Laranja que você tem.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                }
            };


            return View(clientes);
        }
    }
}
