namespace empresa.Models{

    class Empresa{

        public int Id { get; set; }
        public string Nome{ get; set; } = "";
        public decimal Taxa {get; set; }
        public string Endere�o {get; set;} = "";
        public string Cnpj { get; set; } = "";

        public string Fiscal { get; set; } = "";

        public DateTime Data { get; set; }

    }


}